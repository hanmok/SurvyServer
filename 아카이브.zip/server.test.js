// test('1+1 === 2', () => {
// 	expect(1+1).toEqual(2); // expect(실제 코드).toEqual(예상 결과값)
// })
